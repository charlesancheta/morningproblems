/*
  Submit just this .cpp file without zipping it.

  You may include other files from the standard library if you want.
  C++11 features are permitted.

  You can share pseudocode or other ideas you had in the comments here
  in case you were not able to fully solve the problem. Keen observations
  or good pseudocode might be worth partial credit.
*/

#include <iostream>
#include <vector>
#include <algorithm>
#include <unordered_set>
#include <unordered_map>
#include <utility>
using namespace std;

// NAIVE APPROACH TAKES ~55 SECONDS AT N = 3000
int naive(vector<int> a, int n) {
  int est = 0;
  int i = 0, j = 1, k = 2;
  while (i < n - 2) {
    j = i + 1;
    while (j < n - 1) {
      k = j + 1;
      while (k < n) {
        if (2 * a[j] == a[i] + a[k]) {
          ++est;
        }
        ++k;
      }
      ++j;
    }
    ++i;
  }
  return est;
}

// n^2 ??
int mat(vector<int> a, int n) {
  int est = 0;
  // distance then index
  unordered_map<int, int> row;
  unordered_set<triple> valid;
  for (int i = 0; i < n; i++) {
    row.clear();
    for (int j = 0; j < n; j++) {
      int dist = abs(a[i] - a[j]);
      if (i == j) {
        row[dist] = j;
        continue;
      }
      auto query = row.find(dist);
      if (query != row.end()) {
        triple t = triple(query->second, i, j);
        if (valid.find(t) == valid.end()) {
          est++;
          valid.insert(t);
        }
      } else {
        row[dist] = j;
      }
    }
  }
  return est;
}

int main() {
  // get input
  int n;
  cin >> n;
  vector<int> a(n);
  for (int i = 0; i < n; i++) {
    cin >> a[i];
  }

  // attempt to solve problem :(
  cout << mat(a, n) << endl;

  return 0;
}
