/*
  Template file for question2. Answer all parts in the space indicates below
  (look in the comments). Do not modify any other sections of code.

  You may NOT include any other headers beyond the ones that are already included.

  Ideally, this file would compile properly so we can run it and see the
  correct output produced by main(). Incorrect or incomplete parts may be eligible
  for partial.

  You may use C++11 features.
*/

#include <iostream>
#include <cmath>
#include <map>

using namespace std;

// PART 1
void part1(int array[100]) {
  // Your entire solution for part 1 should appear here in the implementation
  // of this function.
  for (int i = 0; i < 100; i++) {
    if (!(array[i] % 10)) {
      array[i] = 10;
    } else if (!(array[i] % 5)) {
      array[i] = 5;
    } else if (!(array[i] % 2)) {
      array[i] = 2;
    } else {
      array[i] = 1;
    }
  }
}

// PART 2
unsigned int part2(unsigned int n) {
  unsigned int m;
  // answer part 2 by writing a SINGLE LINE of code just below this comment
  m = (n >> 16) | (n << 16);

  return m;
}

// PART 3
// Declare the struct and provide the implementation of the two methods
// in the space below before PART 4 starts.

struct triangle {
  unsigned int s1, s2, s3;
  bool isValid() const;
  double area() const;
};

bool triangle::isValid() const {
  unsigned int a[] = {s1, s2, s3};
  for (int i = 0; i < 3; i++) {
    if (a[i] >= (a[(i + 1) % 3] + a[(i + 2) % 3])) {
      return false;
    }
  }
  return true;
}

double triangle::area() const {
  double p = static_cast<double>(s1 + s2 + s3) / 2;
  return sqrt(p * (p - s1) * (p - s2) * (p - s3));
}

// PART 4
void part4() {
  // Replace MY ANSWER below with the proper answer to part 4.

  cout << "Counts the number of characters in a C string (not including null terminator)" << endl;
}

// PART 5
int part5(const map<int, int*>& mymap) {
  // Compute the answer and return it from this function.
  int sum = 0;
  for (auto it = mymap.begin(); it != mymap.end(); it++) {
    // it->second will return zero if it's a null pointer
    if (!it->second) {
      sum += it->first;
    }
  }
  return sum;
}


// NOTHING you put below here will affect your mark. We have our own tests that we
// will copy/paste below, which will override anything you did. Only what you
// type above will be considered for marks.
int main() {
  cout << "PART 1" << endl;
  int array[100];
  part1(array);
  for (int i = 0; i < 100; ++i) {
    cout << i << " : " << array[i] << endl;
  }
  cout << endl;

  // Checking part 2
  // hex and dec are not variables, they are output formatting flags
  cout << "PART 2" << endl;
  cout << hex << part2(0xabcd1234ul) << endl;
  cout << dec << endl; // convert output back to base 10 format

  // Checking part 3

  cout << "PART 3" << endl;
  // Commented out so the file compiles as is.
  triangle t1 = {1, 2, 3};
  cout << t1.isValid() << endl; // should be invalid
  triangle t2 = {2, 2, 3};
  cout << t2.isValid() << ' ' << t2.area() << endl; // should be valid
  
  cout << endl;

  // Checking part 4
  cout << "PART 4" << endl;
  part4();
  cout << endl;


  // Checking part 5
  cout << "PART 5" << endl;
  map<int, int*> mymap;
  int num = 5;

  mymap[-2] = NULL;
  mymap[5] = NULL;
  mymap[7] = &num;
  cout << part5(mymap) << endl;
  cout << endl;

  return 0;
}