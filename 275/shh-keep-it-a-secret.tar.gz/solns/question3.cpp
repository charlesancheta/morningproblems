// 1. Explain why this code has a memory leak 
// The allocated memory for strings in names is not freed
// 2. Modify this code to fix the memory leak

#include <iostream>
#include <cstring>
using namespace std;

struct booknames {
  int num;
  string* names;
};

void init_booknames(int num, booknames* lib) {
  lib->num = num;
  lib->names = new string[num+1];
  for (int i=0;i<=num;i++)
    lib->names[i] = "Book " + to_string(num+i);
}

int main() {
  booknames* libs = new booknames[10];
  for (int i=0;i<10;i++)
    init_booknames(i, libs+i);
  cout << (libs+6)->names[0] << endl;
  // loop over array of booknames to delete string array
  for (int i = 0; i < 10; i++)
    delete[] (libs + i)->names;
  delete[] libs;
  return 0;
}