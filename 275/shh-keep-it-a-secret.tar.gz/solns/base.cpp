#include <iostream>
using namespace std;

class Base {
  public:
  Base() {
    cout << "I was called!" << endl;
  }
};

class Derived : public Base {
  public:
  Derived(int x) {
    cout << x << endl;

    cout << "kek" << endl;
  }
};

int main() {
  Derived kek(1);

  return 0;
}