/*
  Submit just this .cpp file without zipping it.

  You may include other files from the standard library if you want.
  C++11 features are permitted.

  You can share pseudocode or other ideas you had in the comments here
  in case you were not able to fully solve the problem. Keen observations
  or good pseudocode might be worth partial credit.
*/

#include <iostream>
#include <vector>
#include <unordered_map>
#include <unordered_set>
using namespace std;

/*
  I have spent the last 18 hours on this question
  Getting close to O(n^2) meant that I would fail 60% of the cases 
  Please release a solution for the sake of my sanity
*/


// NAIVE APPROACH TAKES ~55 SECONDS AT N = 3000
int takeTheL(vector<int> a, int n) {
  int est = 0;
  int i = 0, j = 1, k = 2;
  while (i < n - 2) {
    j = i + 1;
    while (j < n - 1) {
      k = j + 1;
      while (k < n) {
        if (2 * a[j] == a[i] + a[k]) {
          ++est;
        }
        ++k;
      }
      ++j;
    }
    ++i;
  }
  return est;
}

// struct triple to store 3 integers in a set
struct triple {
  int i, j, k;
  bool operator==(const triple& rhs) const {
    int a[] = {i, j, k};
    int b[] = {rhs.i, rhs.j, rhs.k};
    int match = 0;
    for (int x = 0; x < 3; x++) {
      if (a[x] == b[x]) {
        match++;
      }
    }
    return match == 3;
  }
  // constructor always sorts indices in increasing order
  triple(int x, int y, int z) {
    int a[] = {x, y, z};
    if (a[0] > a[1]) swap(a[0], a[1]);
    if (a[1] > a[2]) swap(a[1], a[2]);
    if (a[0] > a[1]) swap(a[0], a[1]);
    i = x, j = y, k = z;
  }
};

namespace std {
  template<>
  struct hash<triple> {
    long long operator()(const triple& h) const {
      long long a[] = {h.i, h.j, h.k};
      return (a[0] << 32) | (a[1] << 16) | a[2];
    }
  };
}

// n^2 ??
int mat(vector<int> a, int n) {
  int est = 0;
  // distance then index
  unordered_map<int, int> row;
  unordered_set<triple> valid;
  for (int i = 0; i < n; i++) {
    row.clear();
    for (int j = 0; j < n; j++) {
      int dist = abs(a[i] - a[j]);
      if (i == j) {
        row[dist] = j;
        continue;
      }
      auto query = row.find(dist);
      if (query != row.end()) {
        int xorNum = query->second ^ i ^ j;
        if (!(xorNum == query->second || xorNum == i || xorNum == j)) {
          triple t = triple(query->second, i, j);
          if (valid.find(t) == valid.end()) {
            est++;
            valid.insert(t);
          }
        }
      } else {
        row[dist] = j;
      }
    }
  }
  return est;
}

int main() {
  // get input
  int n;
  cin >> n;
  vector<int> a(n);
  for (int i = 0; i < n; i++) {
    cin >> a[i];
  }

  // attempt to solve problem :(
  cout << takeTheL(a, n) << endl;

  return 0;
}
