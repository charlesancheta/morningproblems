#include <iostream>
using namespace std;

bool match(int *a, int *b)  {
  int match = 0;
  for (int x = 0; x < 3; x++) {
    for (int y = 0; y < 3; y++) {
      if (a[x] == b[y]) {
        match++;
        break;
      }
    }
  }
  return match == 3;
}

int main() {
  int a[] = {0, 1, 2};
  int b[] = {2, 1, 0};
  if (match(a, b)) {
    cout << "same" << endl;
  }

  return 0;
}