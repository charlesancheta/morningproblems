/*
  Submit just this .cpp file without zipping it.

  You may include other files from the standard library if you want.
  C++11 features are permitted.

  You can share pseudocode or other ideas you had in the comments here
  in case you were not able to fully solve the problem. Keen observations
  or good pseudocode might be worth partial credit.
*/

#include <iostream>
#include <vector>
#include <algorithm>
#include <unordered_set>
#include <unordered_map>
using namespace std;

int diagMatrixMethod(vector<int> a, int n) {
  int est = 0;
  // build diagonal matrix
  vector<vector<int>> matrix(n);  
  for (int i = 0; i < n; i++) {
    for (int j = 0; j <= i; j++) {
      matrix[i].push_back(abs(a[i] - a[j]));
    }
  }
  for (int i = n - 1; i > 0; i--) {
    for (int j = 0; j < matrix[i].size() - 1; j++) {
      if (matrix[i][j] == 2 * matrix[i][j + 1]) {
        est++;
      }
    }
  }
  return est;
}

int main() {
  // get input
  int n;
  cin >> n;
  vector<int> a(n);
  for (int i = 0; i < n; i++) {
    cin >> a[i];
  }

  // attempt to solve problem :(
  cout << diagMatrixMethod(a, n) << endl;

  return 0;
}
